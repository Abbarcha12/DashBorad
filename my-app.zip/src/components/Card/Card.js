import React from 'react'
import './Card.css'

import Box from '@mui/material/Box'

const card = (props) => {
  return (
    <Box className='Cards'>
      <Box className=' dark-shadow'>
        <Box className='shadow'>
      </Box>

      </Box>
  </Box>
  )
}

export default card