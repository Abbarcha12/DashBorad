import React from 'react'
import Overview from "../../components/Overview/Overview"
import Tabs from '../../components/Tabs/Tabs'

function Rightbar() {
  return (
    <div className=''>
      <Overview />
      <Tabs />
    </div>
  )
}

export default Rightbar