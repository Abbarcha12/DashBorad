import React from 'react'
import './Tabs.css'

function Tabs() {
  return (
    <div>Tabs</div>
  )
}

export default Tabs